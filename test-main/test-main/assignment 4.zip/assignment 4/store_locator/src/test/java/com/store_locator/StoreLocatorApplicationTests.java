package com.store_locator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreLocatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
